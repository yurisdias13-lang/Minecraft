tag @e[type=minecraft:chicken,x=-782,y=65,z=-320,dx=1,dy=1,dz=0,tag=!egg_layer,tag=!pen_chicken] add bc_g_mover
effect give @e[tag=bc_g_mover] minecraft:fire_resistance 5 0 true
execute as @e[tag=bc_g_mover,nbt={NoAI:1b}] run data merge entity @s {NoAI:0b,Motion:[0.0d,0.0d,0.0d]}
tp @e[tag=bc_g_mover] -783 64 -333
tag @e[tag=bc_g_mover] add pen_chicken
tag @e[tag=bc_g_mover] remove bc_g_mover
setblock -781 65 -320 minecraft:glass
setblock -781 66 -320 minecraft:glass
setblock -782 65 -320 minecraft:smooth_stone_slab[type=bottom]
setblock -782 66 -320 minecraft:lava
tellraw @a {"text":"Farm corrigida: camara 1x1. Pintinhos protegidos do fogo ate crescer; adultas viram frango assado.","color":"green"}
data modify storage base_galinhas:config enabled set value 1b
