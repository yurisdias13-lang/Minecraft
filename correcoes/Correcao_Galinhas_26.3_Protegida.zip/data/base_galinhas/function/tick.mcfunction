execute if data storage base_galinhas:config {enabled:1b} run function base_galinhas:proteger
