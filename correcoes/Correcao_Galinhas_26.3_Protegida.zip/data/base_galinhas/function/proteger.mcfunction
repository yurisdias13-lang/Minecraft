tag @e[type=minecraft:chicken,tag=!egg_layer,tag=!pen_chicken,x=-782,y=64,z=-320,dx=0,dy=4,dz=0] add bc_g_managed
execute as @e[type=minecraft:chicken,tag=bc_g_managed] unless entity @s[x=-782,y=64,z=-320,dx=0,dy=4,dz=0] run function base_galinhas:liberar
execute as @e[type=minecraft:chicken,tag=bc_g_managed] store result score @s bc_g_age run data get entity @s Age
execute as @e[type=minecraft:chicken,tag=bc_g_managed,scores={bc_g_age=..-1},nbt=!{NoAI:1b}] run data merge entity @s {NoAI:1b}
effect give @e[type=minecraft:chicken,tag=bc_g_managed,scores={bc_g_age=..-1}] minecraft:fire_resistance 2 0 true
execute as @e[type=minecraft:chicken,tag=bc_g_managed,scores={bc_g_age=0..}] run function base_galinhas:liberar
scoreboard players reset @e[type=minecraft:chicken,tag=bc_g_managed] bc_g_age
tp @e[type=minecraft:item,x=-782,y=65,z=-320,dx=0,dy=4,dz=0,nbt={Item:{id:"minecraft:cooked_chicken"}}] -781.5 65.5 -319.5
tp @e[type=minecraft:item,x=-782,y=65,z=-320,dx=0,dy=4,dz=0,nbt={Item:{id:"minecraft:feather"}}] -781.5 65.5 -319.5
