data modify storage base_galinhas:config enabled set value 0b
execute as @e[type=minecraft:chicken,tag=bc_g_managed] run data merge entity @s {Fire:0s}
execute as @e[type=minecraft:chicken,tag=bc_g_managed] run function base_galinhas:liberar
tellraw @a {"text":"Protecao desativada. Pode remover o datapack; a camara 1x1 permanece.","color":"yellow"}
