execute if entity @s[nbt={NoAI:1b}] run data merge entity @s {NoAI:0b,Motion:[0.0d,0.0d,0.0d]}
effect clear @s minecraft:fire_resistance
scoreboard players reset @s bc_g_age
tag @s remove bc_g_managed
