scoreboard objectives add bc_g_age dummy
execute unless data storage base_galinhas:config enabled run data modify storage base_galinhas:config enabled set value 0b
